import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'screens/home_screen.dart';
import 'screens/about_screen.dart';
import 'screens/privacy_screen.dart';
import 'screens/disclaimer_screen.dart';

void main() {
  runApp(const UGBAcademicVaultApp());
}

class UGBAcademicVaultApp extends StatelessWidget {
  const UGBAcademicVaultApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UGB Academic Vault',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1976D2), // Blue
          secondary: const Color(0xFF00897B), // Teal
          tertiary: const Color(0xFF6A1B9A), // Purple
          brightness: Brightness.light,
        ),
        cardTheme: const CardThemeData(
          elevation: 3,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(16)),
          ),
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 2,
        ),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const SplashScreen(),
        '/home': (context) => const HomeScreen(),
        '/about': (context) => const AboutScreen(),
        '/privacy': (context) => const PrivacyScreen(),
        '/disclaimer': (context) => const DisclaimerScreen(),
      },
    );
  }
}
