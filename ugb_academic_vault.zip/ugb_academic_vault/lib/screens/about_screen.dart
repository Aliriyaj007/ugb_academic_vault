import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('About App'),
        elevation: 2,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionTitle('Purpose of This App'),
            _buildParagraph(
              'UGB Academic Vault exists to provide students of the University of Gourbanga with a single, clean place to access academic materials such as previous year question papers, notes, syllabus, suggestions, and other useful resources.\n\n'
              'This app does not host any content itself. All materials are stored and managed using Google Drive. The app simply provides organized access to those folders in an easy and student-friendly way.\n\n'
              'There is no login, no tracking, and no data collection. Anyone can use the app freely.'
            ),
            
            _buildSectionTitle('How to Use This App'),
            _buildNumberedList([
              'Open the app.',
              'On the home screen, select the section you want (for example, Courses).',
              'The app will open the relevant Google Drive folder inside the app.',
              'Browse folders just like Google Drive.',
              'Tap on any PDF to view it.',
              'You can download files, open them in the Google Drive app, or open them in your browser.',
              'New files appear automatically when they are added to Drive. No app update is needed.',
            ]),
            
            _buildSectionTitle('Courses Section – Folder Structure Rules'),
            _buildParagraph(
              'All academic materials must follow a fixed folder structure so that everything stays organized and easy to find.\n\n'
              'Each course must have its own folder.\n\n'
              'Inside each course folder, create the following subfolders:'
            ),
            _buildBulletList([
              'PYQ',
              'NOTES',
              'SYLLABUS',
              'SUGGESTIONS',
              'RECOMMENDED MATERIALS',
              'USEFUL FILES',
            ]),
            
            _buildSectionTitle('How to Upload Your Study Materials'),
            _buildNumberedList([
              'Open the app.',
              'Go to "Upload Materials".',
              'You will be redirected to a Google Drive upload folder.',
              'Upload your PDF file (maximum size 50 MB).',
              'Name the file clearly (subject, year, topic).',
              'The admin will review your file.',
              'If approved, it will be moved to the correct course and section folder.',
            ]),
            _buildParagraph('Uploads are reviewed manually. Not all uploads are guaranteed to be published.'),
            
            _buildSectionTitle('Supported Programs'),
            _buildSubSectionTitle('UG Programs'),
            _buildBulletList([
              'B.A. (Hons.) in Bengali, English, Hindi, Sanskrit, Arabic',
              'B.A. (Hons.) in History, Political Science, Philosophy, Sociology',
              'B.A. (Hons.) in Economics, Education, Mass Communication & Journalism',
              'B.Sc. (Hons.) in Physics, Chemistry, Zoology, Botany, Mathematics',
              'B.Sc. (Hons.) in Computer Science, Geography, Food & Nutrition',
              'B.Com. (Hons.), BCA, B.A. LL.B., B.Ed.',
              'B.A./B.Sc./B.Com. General',
            ]),
            
            _buildSubSectionTitle('PG Programs'),
            _buildParagraph('M.A., M.Sc., M.Com., LL.M., M.Lib.I.Sc., Journalism & Mass Communication\n(All relevant Arts, Science, Commerce, and Humanities subjects)'),
            
            _buildSubSectionTitle('Doctoral Programs'),
            _buildParagraph('Ph.D. across Arts, Science, Commerce, Law, and Humanities as per UGC norms.'),
            
            _buildSectionTitle('Why This App Exists'),
            _buildParagraph(
              'Many students struggle to find authentic and organized academic materials.\n\n'
              'UGB Academic Vault was created to:\n'
            ),
            _buildBulletList([
              'Reduce confusion',
              'Save time',
              'Provide centralized access',
              'Avoid unnecessary logins and ads',
              'Keep everything simple and long-term usable',
            ]),
            _buildParagraph('This app is designed to work for years with minimal maintenance.'),
            
            const SizedBox(height: 20),
            _buildFooter(),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 24, bottom: 12),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildSubSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildParagraph(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 14,
          height: 1.6,
        ),
      ),
    );
  }

  Widget _buildNumberedList(List<String> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: items.asMap().entries.map((entry) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 8, left: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${entry.key + 1}. ',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  height: 1.6,
                ),
              ),
              Expanded(
                child: Text(
                  entry.value,
                  style: const TextStyle(
                    fontSize: 14,
                    height: 1.6,
                  ),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildBulletList(List<String> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: items.map((item) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 6, left: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '• ',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  height: 1.6,
                ),
              ),
              Expanded(
                child: Text(
                  item,
                  style: const TextStyle(
                    fontSize: 14,
                    height: 1.6,
                  ),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildFooter() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      alignment: Alignment.center,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          Text(
            'Made with ',
            style: TextStyle(fontSize: 12),
          ),
          Icon(Icons.favorite, size: 14, color: Colors.red),
          Text(
            ' by aliriyaj007',
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
