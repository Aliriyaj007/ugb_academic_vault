import 'package:flutter/material.dart';

class PrivacyScreen extends StatelessWidget {
  const PrivacyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Privacy Policy'),
        elevation: 2,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Privacy Policy',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            
            const Text(
              'UGB Academic Vault does not collect, store, or process any personal user data.\n\n'
              'The app does not require login, registration, or authentication.\n\n'
              'No analytics, tracking tools, cookies, or third-party advertising systems are used.\n\n'
              'All content is accessed via external Google Drive links. Any interaction with Google Drive is governed by Google\'s own privacy policies.\n\n'
              'By using this app, users acknowledge that:\n',
              style: TextStyle(
                fontSize: 14,
                height: 1.8,
              ),
            ),
            
            const SizedBox(height: 8),
            _buildBulletList([
              'Files are hosted externally',
              'Downloads and viewing are handled by Google Drive',
              'The app itself stores no personal information',
            ]),
            
            const SizedBox(height: 16),
            const Text(
              'This privacy policy may be updated only if app functionality changes.',
              style: TextStyle(
                fontSize: 14,
                height: 1.8,
                fontStyle: FontStyle.italic,
              ),
            ),
            
            const SizedBox(height: 40),
            _buildFooter(),
          ],
        ),
      ),
    );
  }

  Widget _buildBulletList(List<String> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: items.map((item) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 6, left: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '• ',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  height: 1.6,
                ),
              ),
              Expanded(
                child: Text(
                  item,
                  style: const TextStyle(
                    fontSize: 14,
                    height: 1.6,
                  ),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildFooter() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      alignment: Alignment.center,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          Text(
            'Made with ',
            style: TextStyle(fontSize: 12),
          ),
          Icon(Icons.favorite, size: 14, color: Colors.red),
          Text(
            ' by aliriyaj007',
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
