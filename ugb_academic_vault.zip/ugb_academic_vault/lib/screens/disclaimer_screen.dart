import 'package:flutter/material.dart';

class DisclaimerScreen extends StatelessWidget {
  const DisclaimerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Disclaimer'),
        elevation: 2,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Disclaimer',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            
            const Text(
              'This is an unofficial academic support application created for educational purposes.\n\n'
              'UGB Academic Vault is not affiliated with or officially endorsed by the University of Gourbanga.\n\n'
              'All content is user-contributed or publicly shared via Google Drive. '
              'The developer does not claim ownership of uploaded materials.\n\n'
              'The developer and app administrators are not responsible for:\n',
              style: TextStyle(
                fontSize: 14,
                height: 1.8,
              ),
            ),
            
            const SizedBox(height: 8),
            _buildBulletList([
              'The accuracy or completeness of materials',
              'Any copyright violations in user-uploaded content',
              'Messages or activities in WhatsApp groups',
              'Changes to Google Drive links or content availability',
            ]),
            
            const SizedBox(height: 16),
            const Text(
              'Users are advised to verify information from official university sources.',
              style: TextStyle(
                fontSize: 14,
                height: 1.8,
                fontWeight: FontWeight.w500,
              ),
            ),
            
            const SizedBox(height: 40),
            _buildFooter(),
          ],
        ),
      ),
    );
  }

  Widget _buildBulletList(List<String> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: items.map((item) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 6, left: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '• ',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  height: 1.6,
                ),
              ),
              Expanded(
                child: Text(
                  item,
                  style: const TextStyle(
                    fontSize: 14,
                    height: 1.6,
                  ),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildFooter() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      alignment: Alignment.center,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          Text(
            'Made with ',
            style: TextStyle(fontSize: 12),
          ),
          Icon(Icons.favorite, size: 14, color: Colors.red),
          Text(
            ' by aliriyaj007',
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
