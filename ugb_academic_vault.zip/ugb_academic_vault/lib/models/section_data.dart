import 'package:flutter/material.dart';

class Section {
  final String name;
  final String url;
  final IconData icon;
  final String description;

  const Section({
    required this.name,
    required this.url,
    required this.icon,
    required this.description,
  });
}

// Static list of all sections
final List<Section> appSections = [
  Section(
    name: 'Courses',
    url: 'https://drive.google.com/drive/folders/1KztwRHtTgySQO2g_HW2qbCB41qqRtyu9?usp=drive_link',
    icon: Icons.school,
    description: 'Access academic materials, PYQ, notes & syllabus',
  ),
  Section(
    name: 'Albums & Memories',
    url: 'https://drive.google.com/drive/folders/1OVaeYMVIhKx6YVMo-zW57t8nRmtfhZNt?usp=drive_link',
    icon: Icons.photo_library,
    description: 'Academic events, seminars & departmental activities',
  ),
  Section(
    name: 'Upload Materials',
    url: 'https://drive.google.com/drive/folders/1eECfOih-UZSolCXAYvYerJi3HkARBj9j?usp=drive_link',
    icon: Icons.upload_file,
    description: 'Share your study materials for review',
  ),
  Section(
    name: 'WhatsApp Groups',
    url: 'https://docs.google.com/document/d/1-w7IwTLlnSsQpjm1vlSssO9i6xByFHI313k_Lk6huvc/edit?usp=sharing',
    icon: Icons.groups,
    description: 'Join student discussion groups',
  ),
  Section(
    name: 'Help & Contact',
    url: 'https://docs.google.com/document/d/1-w7IwTLlnSsQpjm1vlSssO9i6xByFHI313k_Lk6huvc/edit?usp=sharing',
    icon: Icons.help_outline,
    description: 'Get help and contact information',
  ),
];
