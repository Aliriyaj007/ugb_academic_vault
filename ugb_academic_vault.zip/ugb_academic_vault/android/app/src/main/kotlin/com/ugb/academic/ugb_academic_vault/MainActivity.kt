package com.ugb.academic.ugb_academic_vault

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
