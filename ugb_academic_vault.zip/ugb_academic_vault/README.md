# UGB Academic Vault

A lightweight Flutter Android application providing University of Gourbanga students with organized access to academic materials via Google Drive.

## 📱 Features

- **WebView-Based**: All content accessed via Google Drive
- **No User Data**: Zero tracking, analytics, or data collection
- **No Login Required**: Instant access for all users
- **Material Design 3**: Modern, colorful UI with gradients
- **Lightweight**: Minimal dependencies, fast performance
- **Offline UI**: App UI loads instantly
- **Auto-Updates**: Content automatically updates via Drive

## 🎨 Sections

1. **Courses** - Academic materials, PYQ, notes & syllabus
2. **Albums & Memories** - Events, seminars & activities
3. **Upload Materials** - Share study materials for review
4. **WhatsApp Groups** - Join student discussion groups
5. **Help & Contact** - Support and information

## 🚀 Quick Start

### Prerequisites

- [Flutter SDK](https://flutter.dev/docs/get-started/install) (3.0+)
- Android Studio or VS Code
- Android device or emulator

### Installation

```bash
# Clone the repository
cd ugb_academic_vault

# Install dependencies
flutter pub get

# Run the app
flutter run
```

### Build APK

```bash
# Build release APK
flutter build apk --release

# APK location: build/app/outputs/flutter-apk/app-release.apk
```

### Build for Play Store

```bash
# Build App Bundle
flutter build appbundle --release

# Bundle location: build/app/outputs/bundle/release/app-release.aab
```

## 📁 Project Structure

```
lib/
├── main.dart                    # App entry point
├── models/
│   └── section_data.dart        # Section data model
├── screens/
│   ├── splash_screen.dart       # Animated splash
│   ├── home_screen.dart         # Main home screen
│   ├── webview_screen.dart      # WebView for Drive
│   ├── about_screen.dart        # About content
│   ├── privacy_screen.dart      # Privacy policy
│   └── disclaimer_screen.dart   # Disclaimer
└── widgets/
    └── app_drawer.dart          # Navigation drawer
```

## 🛠️ Tech Stack

- **Flutter** - Cross-platform framework
- **Dart** - Programming language
- **webview_flutter** - WebView plugin
- **Material Design 3** - Design system

## 📝 Configuration

### Update Google Drive Links

Edit `lib/models/section_data.dart` to update section URLs:

```dart
final List<Section> appSections = [
  Section(
    name: 'Courses',
    url: 'YOUR_DRIVE_URL_HERE',
    icon: Icons.school,
    description: 'Your description',
  ),
  // ... more sections
];
```

### Change App Name

Update `android/app/src/main/AndroidManifest.xml`:

```xml
<application
    android:label="Your App Name"
    ...>
```

## 🎯 Design Philosophy

- **No Overengineering**: Simple, focused solution
- **Privacy First**: Zero data collection
- **Drive-Controlled**: Content managed via Google Drive
- **Low Maintenance**: Minimal app updates needed
- **Play Store Ready**: Follows Android guidelines

## 📄 License

This project is for educational purposes for University of Gourbanga students.

## 👨‍💻 Developer

**Made with ❤️ by aliriyaj007**

- Email: Aliriyaj007@protonmail.com
- GitHub: [@aliriyaj007](https://github.com/aliriyaj007)

## 🤝 Contributing

To contribute study materials:

1. Open the "Upload Materials" section in the app
2. Upload your PDF (max 50 MB)
3. Name the file clearly (subject, year, topic)
4. Admin will review and approve

## ⚠️ Disclaimer

This is an unofficial academic support application. Not affiliated with or endorsed by the University of Gourbanga.

## 📞 Support

For queries or issues:
- Email: Aliriyaj007@protonmail.com
- GitHub Issues: Create an issue on the repository

---

**UGB Academic Vault** - Simplifying access to academic resources
